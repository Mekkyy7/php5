<!DOCTYPE html>
<html>
<body>

<?php
echo "Greg website!";
?>

</body>
</html>
