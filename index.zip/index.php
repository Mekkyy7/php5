<!DOCTYPE html>
<html>
<body>

<?php
echo "This is Greg web site version 2";
?>

</body>
</html>