<!DOCTYPE html>
<html>
<body>

<?php
echo "This is Greg web site version 666666666";
?>

</body>
</html>
